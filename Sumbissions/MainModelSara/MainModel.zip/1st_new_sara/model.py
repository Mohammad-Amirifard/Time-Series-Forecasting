import os
import tensorflow as tf
import numpy as np

class model:

    def __init__(self, path):
        self.model = tf.keras.models.load_model(os.path.join(path, '1st_model_new_sara'))

    def predict(self, X, categories):      
        
        window = 50
        X = X[:, -window:]
        X = np.expand_dims(X, axis=-1)
        out = self.model.predict(X)
        out = np.squeeze(out, axis=-1)

        return out